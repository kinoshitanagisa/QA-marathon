const config = {
  apiUrl: 'http://localhost:3518' //APIサーバーのベースURLのポート番号3000を変更　12/11木下 //ホスト名localhost → dbに修正　12/12（木下）
};

export default config;